#ifndef __BOOLEAN
#define __BOOLEAN

// Ja, es ist auch moeglich, <stdbool.h> zu nutzen ;-)

// Definiere Konstanten
#define TRUE 1
#define FALSE 0

#endif
